"""Shared orchestration for submitting a file to GTI and ingesting the result into Sentinel.

Used by both BlobScanTrigger (automatic, blob-triggered) and ManualScanTrigger
(HTTP-triggered on-demand) so the two entry points share one code path.
"""

import inspect

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.keyvault_secrets_management import KeyVaultSecretManage
from SharedCode.gti_file_scan_client import GTIFileScanClient
from SharedCode.sentinel import send_data_to_sentinel


def scan_file_and_ingest(
    file_name: str, file_content: bytes, file_size: int, extra_params: dict = None
) -> dict:
    """Submit a file to GTI, poll until analysis completes, and ingest the report into Sentinel.

    Args:
        file_name (str): Name of the file (used as the multipart filename for submission).
        file_content (bytes): Raw file content.
        file_size (int): Size of the file in bytes.
        extra_params (dict, optional): Additional GTI upload form fields to forward to
            GTIFileScanClient.submit_file (e.g. password, disable_sandbox, storage_region).

    Returns:
        dict: A summary of the scan result (analysisId, sha256, verdict, severity, size).

    Raises:
        GTIFileScanException: If any step of submission, polling, report retrieval,
            or ingestion fails.
    """
    __method_name = inspect.currentframe().f_code.co_name
    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "Retrieving GTI API key from Key Vault secret '{}'.".format(consts.KEYVAULT_SECRET_NAME),
        )
    )
    api_key = KeyVaultSecretManage().get_keyvault_secret(consts.KEYVAULT_SECRET_NAME)
    client = GTIFileScanClient(api_key)

    applogger.info(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "Submitting file '{}' ({} bytes) to GTI for scanning.".format(file_name, file_size),
        )
    )
    analysis_id = client.submit_file(file_name, file_content, file_size, extra_params)
    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "submit_file returned analysis_id={}. Starting poll_analysis.".format(analysis_id),
        )
    )

    sha256 = client.poll_analysis(analysis_id)
    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "poll_analysis returned sha256={}. Fetching file report.".format(sha256),
        )
    )

    report = client.get_file_report(sha256)
    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "Fetched file report, ingesting into table '{}'.".format(consts.GTI_FILE_SCAN_TABLE_NAME),
        )
    )

    send_data_to_sentinel(report, consts.GTI_FILE_SCAN_TABLE_NAME)

    attributes = report.get("attributes", {})
    gti_assessment = attributes.get("gti_assessment", {})
    result = {
        "fileName": file_name,
        "analysisId": analysis_id,
        "sha256": attributes.get("sha256"),
        "verdict": gti_assessment.get("verdict", {}).get("value"),
        "severity": gti_assessment.get("severity", {}).get("value"),
        "typeDescription": attributes.get("type_description"),
        "size": attributes.get("size"),
    }

    applogger.info(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "FileScanHelper",
            "Completed scan and ingestion for file '{}': {}".format(file_name, result),
        )
    )
    return result
