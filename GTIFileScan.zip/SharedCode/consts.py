"""Module with constants and configurations for the Google Threat Intelligence File Scan connector."""

import os

LOG_LEVEL = os.environ.get("LogLevel", "INFO")
LOGS_STARTS_WITH = "GoogleThreatIntelligence"
LOG_FORMAT = "{}(method = {}) : {} : {}"

# *Sentinel related constants
SCOPE = os.environ.get("SCOPE", "https://monitor.azure.com//.default")
AZURE_DATA_COLLECTION_ENDPOINT = os.environ.get("AZURE_DATA_COLLECTION_ENDPOINT", "")
DCR_RULE_ID = os.environ.get("AZURE_DATA_COLLECTION_RULE_ID", "")
GTI_FILE_SCAN_TABLE_NAME = os.environ.get("GTIFileScanTableName", "GTI_FileScan")

# *KeyVault related constants
KEYVAULT_NAME = os.environ.get("KEYVAULT_NAME", "")
KEYVAULT_SECRET_NAME = os.environ.get("KeyVaultSecretName", "GTIApiKey")
ZIP_PASSWORD_SECRET_NAME = os.environ.get("ZipPasswordSecretName", "")

# *GTI upload parameter defaults for BlobScanTrigger (auto-triggered scans have no
# per-file request body, so these are fixed at deploy time). Values match GTI's own
# documented defaults unless overridden.
DISABLE_SANDBOX = os.environ.get("DisableSandbox", "false")
STORAGE_REGION = os.environ.get("StorageRegion", "")  # "" = unset, GTI uses group default

# *Storage related constants (storage account containing the files to be scanned)
STORAGE_ACCOUNT_NAME = os.environ.get("StorageAccountName", "")
CONTAINER_NAME = os.environ.get("ContainerName", "")

# *GTI (VirusTotal) related constants
GTI_BASE_URL = os.environ.get("GTIBaseUrl", "https://www.virustotal.com")
USER_AGENT = "azure-sentinel-gti-filescan-function/1.0"

# *Error messages for exceptions
UNEXPECTED_ERROR_MSG = "Unexpected error : Error-{}"
CONNECTION_ERROR_MSG = "Connection error : Error-{}"
TYPE_ERROR_MSG = "Type error : Error-{}"
JSON_DECODE_ERROR_MSG = "JSONDecode error : Error-{}"
TIME_OUT_ERROR_MSG = "Timeout error : Error-{}"
MAX_RETRY_ERROR_MSG = "Max retries exceeded : {} Last exception: {}"

# *Retry and timeout constants
MAX_RETRIES = 3
# GTI dedupes concurrent submissions of the same file content and returns
# 503 TransientError ("Concurrently processing matching analysis") when another
# submission of the same hash is already being analyzed elsewhere (e.g. BlobScanTrigger
# already picked up a file that is then also submitted via ManualScanTrigger). This is
# expected and clears once the other analysis finishes, so submit_file gets a much
# longer retry budget than other GTI calls: 10+20+40+80+160+320+640 = ~21 minutes.
SUBMIT_MAX_RETRIES = 8
BACKOFF_MULTIPLIER = 2
MIN_SLEEP_TIME = 10
MAX_SLEEP_TIME = 3600
MAX_TIMEOUT_SENTINEL = 120
LARGE_FILE_UPLOAD_TIMEOUT = 1800

# *Status code handling
RETRY_STATUS_CODE = [429, 500, 503, 502, 509]

# *File scanning constants
LARGE_FILE_THRESHOLD_BYTES = 32 * 1024 * 1024  # 32 MB
INITIAL_POLL_DELAY_SECONDS = 30
MAX_POLL_DELAY_SECONDS = 180
MAX_POLL_SECONDS = 3600  # 1 hour, matches the playbooks' polling budget
