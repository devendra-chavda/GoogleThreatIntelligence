"""This file contains custom exception classes for the Google Threat Intelligence File Scan connector."""


class GTIFileScanException(Exception):
    """Exception class to handle Google Threat Intelligence File Scan connector exceptions.

    Args:
        Exception (string): Will print exception message.
    """

    def __init__(self, message=None) -> None:
        """Initialize custom GTI File Scan exception with custom message."""
        super().__init__(message)


class GTIFileScanAuthException(Exception):
    """Exception class to handle Google Threat Intelligence File Scan authentication failures.

    Raised when Key Vault secret retrieval or Sentinel ingestion authentication fails.

    Args:
        Exception (string): Will print exception message.
    """

    def __init__(self, message=None) -> None:
        """Initialize custom GTI File Scan authentication exception with custom message."""
        super().__init__(message)


class GTIFileScanBlobException(Exception):
    """Exception class to handle Azure Blob Storage access failures.

    Args:
        Exception (string): Will print exception message.
    """

    def __init__(self, message=None) -> None:
        """Initialize custom GTI File Scan blob exception with custom message."""
        super().__init__(message)
