"""Azure Blob Storage access for the GTI File Scan connector.

Used by the manual-trigger function, which is not bound to a blob input binding and
must fetch blob content/metadata itself. The blob-trigger function receives its blob
content directly through the Functions binding and does not use this module.
"""

import inspect

from azure.identity import ManagedIdentityCredential
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import GTIFileScanBlobException


class BlobHelper:
    """Read blob content and metadata from Azure Blob Storage using Managed Identity."""

    def __init__(self, storage_account_name: str) -> None:
        """Initialize the BlobServiceClient for the given storage account.

        Args:
            storage_account_name (str): Name of the Azure Storage Account to read from.
        """
        self.storage_account_name = storage_account_name
        account_url = "https://{}.blob.core.windows.net".format(storage_account_name)
        self.client = BlobServiceClient(account_url=account_url, credential=ManagedIdentityCredential())

    def get_blob(self, container_name: str, blob_path: str):
        """Fetch a blob's content and size.

        Args:
            container_name (str): Name of the blob container.
            blob_path (str): Path of the blob within the container.

        Returns:
            tuple: (content: bytes, size: int)

        Raises:
            GTIFileScanBlobException: If the blob cannot be read.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            blob_client = self.client.get_blob_client(container=container_name, blob=blob_path)
            properties = blob_client.get_blob_properties()
            content = blob_client.download_blob().readall()
            return content, properties.size
        except ResourceNotFoundError as error:
            applogger.error(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "BlobHelper",
                    "Blob not found. StorageAccount: {}, Container: {}, BlobPath: {}".format(
                        self.storage_account_name, container_name, blob_path
                    ),
                )
            )
            raise GTIFileScanBlobException(
                "Blob not found. StorageAccount: {}, Container: {}, BlobPath: {}".format(
                    self.storage_account_name, container_name, blob_path
                )
            ) from error
        except Exception as error:
            applogger.error(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "BlobHelper",
                    consts.UNEXPECTED_ERROR_MSG.format(error),
                )
            )
            raise GTIFileScanBlobException("Unable to read blob content: {}".format(error)) from error
