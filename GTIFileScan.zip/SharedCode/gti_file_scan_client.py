"""Google Threat Intelligence (VirusTotal) file-scanning API client.

Submits a file for scanning (streaming large files > 32 MB through GTI's dedicated
upload-URL endpoint, matching the behaviour of the retired GTIFileScanBlobEnrichment
and GTIFileScanEnrichment playbooks), polls the analysis until it completes, and
retrieves the final file report.
"""

import inspect
import time
from json.decoder import JSONDecodeError

import requests
from requests.exceptions import ConnectionError as RequestsConnectionError

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import GTIFileScanException


def _backoff_sleep(attempt: int) -> float:
    """Return exponential backoff delay for the given 1-based attempt number."""
    return min(consts.MIN_SLEEP_TIME * (consts.BACKOFF_MULTIPLIER ** (attempt - 1)), consts.MAX_SLEEP_TIME)


class GTIFileScanClient:
    """Client for submitting files to GTI, polling analysis status, and fetching reports."""

    def __init__(self, api_key: str) -> None:
        """Initialize the client with the GTI API key.

        Args:
            api_key (str): Google Threat Intelligence (VirusTotal) API key.
        """
        self.api_key = api_key
        self.base_url = consts.GTI_BASE_URL

    def _headers(self) -> dict:
        return {"x-apikey": self.api_key, "User-Agent": consts.USER_AGENT}

    def _request_with_retry(self, method_name: str, request_fn, max_retries: int = None):
        """Execute an HTTP request with exponential-backoff retry on transient errors.

        Args:
            method_name (str): Caller method name for log context.
            request_fn (callable): Zero-arg callable returning a requests.Response.
            max_retries (int, optional): Overrides consts.MAX_RETRIES for this call
                (e.g. submit_file uses a much larger budget to ride out GTI's
                "Concurrently processing matching analysis" dedup collisions).

        Returns:
            requests.Response: The successful response.

        Raises:
            GTIFileScanException: On timeout, JSON decode error, or retries exhausted.
        """
        max_retries = max_retries or consts.MAX_RETRIES
        last_error = None
        for attempt in range(1, max_retries + 1):
            try:
                applogger.debug(
                    consts.LOG_FORMAT.format(
                        consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                        "Sending request (attempt {}/{})".format(attempt, max_retries),
                    )
                )
                response = request_fn()
                applogger.debug(
                    consts.LOG_FORMAT.format(
                        consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                        "Received status {} (attempt {}/{})".format(response.status_code, attempt, max_retries),
                    )
                )
                if response.status_code in consts.RETRY_STATUS_CODE and attempt < max_retries:
                    sleep_time = _backoff_sleep(attempt)
                    applogger.warning(
                        consts.LOG_FORMAT.format(
                            consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                            "Retryable status {} - retrying in {}s (attempt {}/{}): {}".format(
                                response.status_code, sleep_time, attempt, max_retries, response.text
                            ),
                        )
                    )
                    time.sleep(sleep_time)
                    continue
                return response
            except requests.exceptions.Timeout as error:
                last_error = error
                applogger.error(
                    consts.LOG_FORMAT.format(
                        consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                        consts.TIME_OUT_ERROR_MSG.format(error),
                    )
                )
                raise GTIFileScanException("Timeout during {}: {}".format(method_name, error)) from error
            except RequestsConnectionError as error:
                last_error = error
                if attempt < max_retries:
                    sleep_time = _backoff_sleep(attempt)
                    applogger.warning(
                        consts.LOG_FORMAT.format(
                            consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                            "Connection error, retrying in {}s (attempt {}/{}): {}".format(
                                sleep_time, attempt, max_retries, error
                            ),
                        )
                    )
                    time.sleep(sleep_time)
                    continue
            except JSONDecodeError as error:
                applogger.error(
                    consts.LOG_FORMAT.format(
                        consts.LOGS_STARTS_WITH, method_name, "GTIFileScanClient",
                        consts.JSON_DECODE_ERROR_MSG.format(error),
                    )
                )
                raise GTIFileScanException("JSON decode error during {}: {}".format(method_name, error)) from error
        raise GTIFileScanException(consts.MAX_RETRY_ERROR_MSG.format(method_name, last_error))

    def submit_file(
        self, file_name: str, file_content: bytes, file_size: int, extra_params: dict = None
    ) -> str:
        """Submit a file to GTI for scanning, choosing the large-file path when needed.

        Args:
            file_name (str): Name of the file (used as the multipart filename).
            file_content (bytes): Raw file content.
            file_size (int): Size of the file in bytes.
            extra_params (dict, optional): Additional GTI upload form fields to send
                (e.g. password, disable_sandbox, storage_region). Only keys that are
                actually set should be included by the caller — omitted keys let GTI's
                own documented defaults apply. Accepted by both the direct-submit and
                large-file upload_url paths, which share the same request format.

        Returns:
            str: The GTI analysis ID.

        Raises:
            GTIFileScanException: If submission fails or GTI returns no analysis ID.
        """
        __method_name = inspect.currentframe().f_code.co_name
        is_large_file = file_size > consts.LARGE_FILE_THRESHOLD_BYTES
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                "file_name={}, file_size={}, large_file_path={}, extra_params_keys={}".format(
                    file_name, file_size, is_large_file,
                    sorted((extra_params or {}).keys()),
                ),
            )
        )
        if is_large_file:
            upload_url = self._get_large_file_upload_url()
            submit_url = upload_url
            applogger.debug(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                    "Obtained large-file upload URL (not logged; single-use).",
                )
            )
        else:
            submit_url = "{}/api/v3/private/files".format(self.base_url)
            applogger.debug(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                    "Submitting directly to {}".format(submit_url),
                )
            )

        response = self._request_with_retry(
            __method_name,
            lambda: requests.post(
                submit_url,
                headers=self._headers(),
                files={"file": (file_name, file_content)},
                data=extra_params or None,
                timeout=consts.LARGE_FILE_UPLOAD_TIMEOUT,
            ),
            max_retries=consts.SUBMIT_MAX_RETRIES,
        )
        if response.status_code not in (200, 201):
            applogger.error(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                    "GTI API error submitting file for scanning. Status: {}. Response: {}".format(
                        response.status_code, response.text
                    ),
                )
            )
            raise GTIFileScanException(
                "GTI API error submitting file for scanning. Status: {}".format(response.status_code)
            )

        analysis_id = response.json().get("data", {}).get("id")
        if not analysis_id:
            raise GTIFileScanException("GTI API returned a null analysis ID for file: {}".format(file_name))
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                "Submission accepted, analysis_id={}".format(analysis_id),
            )
        )
        return analysis_id

    def _get_large_file_upload_url(self) -> str:
        """Request a dedicated upload URL for files larger than 32 MB.

        Returns:
            str: The one-time upload URL returned by GTI.

        Raises:
            GTIFileScanException: If the upload URL request fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        response = self._request_with_retry(
            __method_name,
            lambda: requests.get(
                "{}/api/v3/private/files/upload_url".format(self.base_url),
                headers=self._headers(),
                timeout=consts.MAX_TIMEOUT_SENTINEL,
            ),
        )
        if response.status_code != 200:
            raise GTIFileScanException(
                "GTI API error requesting large-file upload URL. Status: {}".format(response.status_code)
            )
        return response.json()["data"]

    def poll_analysis(self, analysis_id: str) -> str:
        """Poll a GTI analysis until it completes, with escalating backoff.

        Args:
            analysis_id (str): The analysis ID returned by submit_file.

        Returns:
            str: The SHA256 of the scanned file, taken from the completed analysis.

        Raises:
            GTIFileScanException: If the analysis errors out or the poll budget is exceeded.
        """
        __method_name = inspect.currentframe().f_code.co_name
        poll_delay = consts.INITIAL_POLL_DELAY_SECONDS
        deadline = time.time() + consts.MAX_POLL_SECONDS
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                "Starting poll loop for analysis_id={}, budget={}s".format(analysis_id, consts.MAX_POLL_SECONDS),
            )
        )

        while time.time() < deadline:
            response = self._request_with_retry(
                __method_name,
                lambda: requests.get(
                    "{}/api/v3/private/analyses/{}".format(self.base_url, analysis_id),
                    headers=self._headers(),
                    timeout=consts.MAX_TIMEOUT_SENTINEL,
                ),
            )
            if response.status_code in (400, 404):
                raise GTIFileScanException(
                    "GTI API error polling analysis {}. Status: {}".format(analysis_id, response.status_code)
                )
            if response.status_code != 200:
                raise GTIFileScanException(
                    "Unexpected status polling analysis {}: {}".format(analysis_id, response.status_code)
                )

            body = response.json()
            status = body.get("data", {}).get("attributes", {}).get("status")
            if status == "completed":
                sha256 = body.get("meta", {}).get("file_info", {}).get("sha256")
                if not sha256:
                    raise GTIFileScanException(
                        "GTI analysis {} completed without a sha256 in file_info".format(analysis_id)
                    )
                applogger.debug(
                    consts.LOG_FORMAT.format(
                        consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                        "Analysis {} completed, sha256={}".format(analysis_id, sha256),
                    )
                )
                return sha256

            applogger.info(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                    "Analysis {} status={}, waiting {}s".format(analysis_id, status, poll_delay),
                )
            )
            time.sleep(poll_delay)
            poll_delay = min(poll_delay * 2, consts.MAX_POLL_DELAY_SECONDS)
            applogger.debug(
                consts.LOG_FORMAT.format(
                    consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                    "{}s remaining in poll budget for analysis_id={}".format(
                        int(deadline - time.time()), analysis_id
                    ),
                )
            )

        raise GTIFileScanException(
            "GTI analysis {} did not complete within {}s".format(analysis_id, consts.MAX_POLL_SECONDS)
        )

    def get_file_report(self, sha256: str) -> dict:
        """Fetch the final file report for a scanned file.

        Args:
            sha256 (str): SHA256 of the scanned file.

        Returns:
            dict: The 'data' object from the GTI file report response.

        Raises:
            GTIFileScanException: If the report cannot be retrieved.
        """
        __method_name = inspect.currentframe().f_code.co_name
        headers = self._headers()
        headers["x-tool"] = "azure-sentinel-gti-filescan-function"
        response = self._request_with_retry(
            __method_name,
            lambda: requests.get(
                "{}/api/v3/private/files/{}".format(self.base_url, sha256),
                headers=headers,
                timeout=consts.MAX_TIMEOUT_SENTINEL,
            ),
        )
        if response.status_code != 200:
            raise GTIFileScanException(
                "GTI API error on GET /files/{}. Status: {}".format(sha256, response.status_code)
            )
        report = response.json()["data"]
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "GTIFileScanClient",
                "Fetched file report for sha256={}, size_bytes={}".format(sha256, len(response.content)),
            )
        )
        return report
