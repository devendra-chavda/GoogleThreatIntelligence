"""KeyVault secrets management for the GTI File Scan connector."""

from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential
from azure.core.exceptions import ResourceNotFoundError

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import GTIFileScanAuthException


class KeyVaultSecretManage:
    """Manage secrets in Azure Key Vault using the Function App Managed Identity."""

    def __init__(self) -> None:
        """Initialize the Key Vault client using the configured vault name."""
        self.keyvault_name = consts.KEYVAULT_NAME
        if ".us" in consts.SCOPE:
            self.keyvault_uri = "https://{}.vault.usgovcloudapi.net/".format(self.keyvault_name)
        else:
            self.keyvault_uri = "https://{}.vault.azure.net/".format(self.keyvault_name)
        self.client = self._get_client()

    def _get_client(self):
        """Obtain the Azure Key Vault SecretClient using Managed Identity.

        Returns:
            SecretClient: Authenticated Key Vault client.
        """
        credential = ManagedIdentityCredential()
        return SecretClient(vault_url=self.keyvault_uri, credential=credential)

    def get_keyvault_secret(self, secret_name):
        """Retrieve a secret value from Azure Key Vault.

        Args:
            secret_name (str): Name of the secret to retrieve.

        Returns:
            str: The secret value.

        Raises:
            GTIFileScanAuthException: If the secret does not exist in the vault.
        """
        try:
            applogger.debug("Retrieving secret '{}' from KeyVault '{}'.".format(secret_name, self.keyvault_name))
            retrieved_secret = self.client.get_secret(secret_name)
            applogger.debug("Retrieved secret '{}'.".format(retrieved_secret.name))
            return retrieved_secret.value
        except ResourceNotFoundError:
            applogger.error("Secret '{}' not found in KeyVault '{}'.".format(secret_name, self.keyvault_name))
            raise GTIFileScanAuthException(
                "Secret '{}' not found in KeyVault '{}'.".format(secret_name, self.keyvault_name)
            )
