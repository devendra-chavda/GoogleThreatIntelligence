"""Azure Function Blob Trigger entry point for the GTI File Scan connector.

Fires automatically whenever a new or modified blob appears in the configured
storage container, submits it to Google Threat Intelligence for scanning, and
ingests the resulting file report into GTI_FileScan_CL.
"""

import inspect

import azure.functions as func

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import GTIFileScanException, GTIFileScanAuthException, GTIFileScanBlobException
from SharedCode.file_scan_helper import scan_file_and_ingest
from SharedCode.keyvault_secrets_management import KeyVaultSecretManage


def _build_extra_params() -> dict:
    """Build the fixed GTI upload parameters applied to every auto-triggered scan.

    Blob-triggered scans have no per-file request body, so these are sourced from
    Function App settings (consts) instead of a request. Only non-default values are
    included, so GTI's own documented defaults apply untouched when not configured.

    Returns:
        dict: Extra GTI upload form fields (disable_sandbox, storage_region, password).
    """
    extra_params = {}

    if consts.DISABLE_SANDBOX.lower() != "false":
        extra_params["disable_sandbox"] = "true"

    if consts.STORAGE_REGION:
        extra_params["storage_region"] = consts.STORAGE_REGION

    if consts.ZIP_PASSWORD_SECRET_NAME:
        extra_params["password"] = KeyVaultSecretManage().get_keyvault_secret(consts.ZIP_PASSWORD_SECRET_NAME)

    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, "_build_extra_params", "BlobScanTrigger",
            "Fixed extra_params keys for this deployment: {}".format(sorted(extra_params.keys())),
        )
    )
    return extra_params


def main(myblob: func.InputStream) -> None:
    """Scan a newly added or modified blob and ingest the GTI report into Sentinel.

    Args:
        myblob (func.InputStream): The triggering blob, bound as "<container>/<name>".
    """
    __method_name = inspect.currentframe().f_code.co_name
    blob_path = myblob.name
    file_name = blob_path.rsplit("/", 1)[-1]

    applogger.info(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "BlobScanTrigger",
            "Blob trigger fired for '{}' ({} bytes).".format(blob_path, myblob.length),
        )
    )

    try:
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "BlobScanTrigger",
                "Reading blob content into memory for '{}'.".format(blob_path),
            )
        )
        file_content = myblob.read()
        extra_params = _build_extra_params()
        scan_file_and_ingest(file_name, file_content, myblob.length, extra_params)
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "BlobScanTrigger",
                "Scan and ingest completed for '{}'.".format(blob_path),
            )
        )
    except (GTIFileScanException, GTIFileScanAuthException, GTIFileScanBlobException) as error:
        applogger.error(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "BlobScanTrigger",
                "GTI file scan failed for blob '{}': {}".format(blob_path, error),
            )
        )
        raise
