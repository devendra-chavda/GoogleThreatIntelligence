"""Azure Function HTTP Trigger entry point for on-demand GTI file scans.

Accepts a JSON body identifying a blob (e.g. posted from an Azure Workbook or
analyst tooling), downloads it, submits it to Google Threat Intelligence for
scanning, and ingests the resulting file report into GTI_FileScan_CL.

Request body:
    {
        "containerName": "<container>",
        "blobPath": "<path/to/blob>",
        "storageAccountName": "<optional, defaults to the configured StorageAccountName>",
        "password": "<optional, decompression password for protected ZIP files>",
        "disable_sandbox": "<optional bool, default false>",
        "storage_region": "<optional, one of US/CA/EU/GB, default is the group's preference>"
    }

The last three fields are passed straight through to GTI's upload endpoint; any
omitted field lets GTI apply its own documented default.
"""

import inspect
import json

import azure.functions as func

from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import GTIFileScanException, GTIFileScanAuthException, GTIFileScanBlobException
from SharedCode.blob_helper import BlobHelper
from SharedCode.file_scan_helper import scan_file_and_ingest

VALID_STORAGE_REGIONS = {"US", "CA", "EU", "GB"}


def _error_response(status_code: int, message: str) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps({"error": message}),
        status_code=status_code,
        mimetype="application/json",
    )


def _build_extra_params(body: dict) -> tuple:
    """Extract and validate the optional GTI upload parameters from the request body.

    Args:
        body (dict): Parsed JSON request body.

    Returns:
        tuple: (extra_params: dict, error_message: str or None). If error_message is
            not None, the caller should return a 400 response with that message.
    """
    extra_params = {}

    if "password" in body and body["password"]:
        extra_params["password"] = str(body["password"])

    if "disable_sandbox" in body and body["disable_sandbox"] is not None:
        extra_params["disable_sandbox"] = "true" if str(body["disable_sandbox"]).lower() in (
            "true", "1"
        ) else "false"

    if "storage_region" in body and body["storage_region"]:
        storage_region = str(body["storage_region"]).upper()
        if storage_region not in VALID_STORAGE_REGIONS:
            return {}, "storage_region must be one of {}.".format(sorted(VALID_STORAGE_REGIONS))
        extra_params["storage_region"] = storage_region

    return extra_params, None


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Handle an on-demand file-scan request.

    Args:
        req (func.HttpRequest): The incoming HTTP request.

    Returns:
        func.HttpResponse: 200 with the scan verdict on success, 400/500 on failure.
    """
    __method_name = inspect.currentframe().f_code.co_name

    try:
        body = req.get_json()
    except ValueError:
        return _error_response(400, "Request body must be valid JSON.")

    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
            "Request body keys: {}".format(sorted(body.keys())),
        )
    )

    container_name = body.get("containerName")
    blob_path = body.get("blobPath")
    storage_account_name = body.get("storageAccountName") or consts.STORAGE_ACCOUNT_NAME

    if not container_name or not blob_path:
        return _error_response(400, "containerName and blobPath are required.")
    if not storage_account_name:
        return _error_response(
            400,
            "storageAccountName was not supplied and no default StorageAccountName is configured "
            "on the Function App.",
        )

    extra_params, validation_error = _build_extra_params(body)
    if validation_error:
        return _error_response(400, validation_error)
    applogger.debug(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
            "Request-supplied extra_params keys: {}".format(sorted(extra_params.keys())),
        )
    )

    applogger.info(
        consts.LOG_FORMAT.format(
            consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
            "Manual scan requested for StorageAccount: {}, Container: {}, BlobPath: {}".format(
                storage_account_name, container_name, blob_path
            ),
        )
    )

    try:
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
                "Fetching blob from StorageAccount: {}.".format(storage_account_name),
            )
        )
        file_content, file_size = BlobHelper(storage_account_name).get_blob(container_name, blob_path)
        file_name = blob_path.rsplit("/", 1)[-1]
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
                "Blob fetched ({} bytes). Starting scan_file_and_ingest.".format(file_size),
            )
        )
        result = scan_file_and_ingest(file_name, file_content, file_size, extra_params)
        result.update({"containerName": container_name, "blobPath": blob_path})
        applogger.debug(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger",
                "Returning 200 response: {}".format(result),
            )
        )
        return func.HttpResponse(json.dumps(result), status_code=200, mimetype="application/json")
    except GTIFileScanBlobException as error:
        applogger.error(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger", str(error),
            )
        )
        return _error_response(404, str(error))
    except (GTIFileScanException, GTIFileScanAuthException) as error:
        applogger.error(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH, __method_name, "ManualScanTrigger", str(error),
            )
        )
        return _error_response(500, str(error))
